# OCP 설치 파일

## 사용방법

- 고객사 ocp 클러스터 설치 시, 해당 파일을 git clone 하여 패키징합니다.
- oc, openshift-install, oc-mirror, butane, Quay-Registry 파일은 설치 전 별도로 받아가야 합니다.
- operatorhub의 디렉토리는 추후, 별도의 프로젝트를 생성하여 사이트에 필요한 오퍼레이터 파일만 가져갈 수 있도록 하겠습니다.
- 반영하고 싶은 내용이 있을 경우, push 후 ps1팀 톡에 알려주시면 검토 후, main 브런치에 반영하도록 하겠습니다.



## 디렉터리 구조
``  
├── 00_Install_Config  
│   ├── ipi  
│   └── upi  
├── 01_Instance_Setting  
│   ├── haproxy : HAProxy 및 KeepAlived 설정   
│   ├── mirror-registry  
│   │   ├── containers : 구버전 ContainerRegstiry 구성 위치  
│   │   └── tar-balls : Quay-Regsitry 구성 위치  
│   ├── repo : cd Mount 후, repository를 사용하기 위한 .repo파일 위치  
│   ├── dns  
│   ├── httpd  
│   ├── rhcos  
│   │   └── ignition  
│   └── tuned  
│       └── ulimit  
├── 02_Ssl  
│   ├── client  
│   │   ├── registry  
│   │   ├── router  
│   │   └── vcenter  
│   ├── conf  
│   └── root  
├── 03_Yaml  
│   ├── cronjobs  
│   │   └── etcd-backup  
│   ├── etcd-encryption  
│   ├── idp-oauth  
│   │   ├── htpasswd  
│   │   ├── ms-ad  
│   │   └── openid  
│   ├── machine-config  
│   │   ├── node-role  
│   │   ├── ntp  
│   │   └── unsafe-sysctl  
│   ├── machine-set  
│   ├── monitoring  
│   │   └── prometheus  
│   │       ├── local-storage  
│   │       ├── nfs  
│   │       └── vsphere-csi  
│   ├── network  
│   │   ├── egress-ip  
│   │   ├── network-policy  
│   │   ├── node-port-range  
│   │   ├── ovn-kubernetes  
│   │   └── proxy-enable  
│   ├── operatorhub  
│   │   ├── catalog-source  
│   │   ├── marketplace  
│   │   ├── metallb-operator  
│   │   └── node-health-check  
│   ├── pod-eviction-timeout  
│   ├── registry  
│   │   ├── local-storage  
│   │   ├── nfs  
│   ├── router  
│   │   ├── sharding  
│   ├── sample-apps  
│   │   ├── nginx  
│   │   └── nginx_metallb  
│   ├── tcpdump  
│   │   ├── 00_build  
│   │   ├── 01_yaml  
│   └── tuned  
│       ├── crio  
│       ├── ipv6  
│       └── kubelet  
├── 04_Release_Config  
└── 05_OC_Command  