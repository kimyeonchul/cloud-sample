#!/bin/bash
rm -rf download.zip certs/
curl -k -o "vcenter-certs/download.zip" -L "https://vcenter.vsphere.local/certs/download.zip"
cd vcenter-certs/
unzip download.zip
cp certs/lin/* /etc/pki/ca-trust/source/anchors/
update-ca-trust
update-ca-trust extract
