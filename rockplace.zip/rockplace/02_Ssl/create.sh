#---------------------------------------------------#
# - Title
#     Generating Self-Signed Certificate with OpenSSL
#
# - Script Version
#     v1.0
#
# - OS Supported
#     All
#
# - Required Package
#     OpenSSL
#     https://www.openssl.org/
#
# - Maintainer
#     Rockplace Inc.
#
# - RefURL
#     https://gist.github.com/ruo91/4f620389a05ce130e44f61bd214f23b4
#---------------------------------------------------#
#!/bin/bash
# Global Variables
ROOTCA_DAYS='36500'
CLIENT_DAYS='36500'
ROOTCA='root/rootca.crt'
ROOTCA_CSR='root/rootca.csr'
ROOTCA_KEY='root/rootca.key'
CLIENT_NAME='registry router'
CERT_PASS='rplinux'

# OpenSSL Config
# RootCA
OPENSSL_ROOTCA_CONF='conf/openssl-rootca.conf'
OPENSSL_ROOTCA_COUNTRY_NAME='KR'
OPENSSL_ROOTCA_STATE_NAME='example'
OPENSSL_CLIENT_LOCAL_NAME='example'
OPENSSL_CLIENT_OU_NAME='example'
OPENSSL_ROOTCA_COMMON_NAME='OpenShift - Self Signed RootCA'

# Client
OPENSSL_CLIENT_COUNTRY_NAME='KR'
OPENSSL_CLIENT_STATE_NAME='example'
OPENSSL_CLIENT_LOCAL_NAME='example'
OPENSSL_CLIENT_OU_NAME='example'
OPENSSL_CLIENT_COMMON_ROUTE_NAME='*.apps.example.com'
OPENSSL_CLIENT_COMMON_REGISTRY_NAME='registry.example.com'

# Functios
# Check workdir
function f_check_workdir {
  mkdir -p {root,client,conf}
  for i in ${CLIENT_NAME}; do
    mkdir -p client/$i;
  done
}

# Check OpenSSL config files
function f_check_openssl_conf {
  if [[ ! -e "$OPENSSL_ROOTCA_CONF" ]]; then
    f_create_openssl_rootca_conf
  fi

  for i in ${CLIENT_NAME}; do
    if [[ ! -e "conf/openssl-$i.conf" ]]; then
      f_create_openssl_router_conf
      f_create_openssl_registry_conf
    fi
  done
}

# Check RootCA Certificates
function f_check_rootca {
  if [[ ! -e "$ROOTCA" ]]; then
    f_create_rootca
  fi
}

# Remove all certificates (not recommend)
function f_cert_remove_all {
  for i in ${CLIENT_NAME}; do
    rm -f root/$i/*
    rm -f client/$i/*;
  done
}

# Update CA Trust
function f_update_ca_trust {
  for i in ${CLIENT_NAME}; do
    cp client/$i/$i.crt /etc/pki/ca-trust/source/anchors/
    cp root/rootca.crt /etc/pki/ca-trust/source/anchors/
    update-ca-trust && update-ca-trust extract;
  done
}

# Create OpenSSL RootCA Config files
function f_create_openssl_rootca_conf {
cat << EOF > conf/openssl-rootca.conf
#### RootCA ####
# OpenSSL root CA configuration file.
[req]
# Options for the req tool (man req).
default_bits = 2048
distinguished_name = req_distinguished_name
string_mask = utf8only

# SHA-1 is deprecated, so use SHA-2 instead.
default_md = sha256

# Extension to add when the -x509 option is used.
x509_extensions = v3_ca
req_extensions = v3_req

[v3_req]
# Extensions to add to a certificate request
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment

[req_distinguished_name]
# See <https://en.wikipedia.org/wiki/Certificate_signing_request>.
countryName = Country Name (2 letter code)
stateOrProvinceName = State or Province Name
localityName = Locality Name
0.organizationName = Organization Name
organizationalUnitName = Organizational Unit Name
commonName = Common Name
emailAddress = Email Address

# Optionally, specify some defaults.
countryName_default = "$OPENSSL_ROOTCA_COUNTRY_NAME"
stateOrProvinceName_default = "$OPENSSL_ROOTCA_STATE_NAME"
localityName_default = "$OPENSSL_ROOTCA_LOCAL_NAME"
organizationalUnitName_default = "$OPENSSL_ROOTCA_OU_NAME"
commonName_default = "$OPENSSL_ROOTCA_COMMON_NAME"

[v3_ca]
# Extensions for a typical CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[v3_intermediate_ca]
# Extensions for a typical intermediate CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true, pathlen:0
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[server_cert]
# Extensions for server certificates (man x509v3_config).
basicConstraints = CA:FALSE
nsCertType = server
nsComment = "OpenSSL Generated Server Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer:always
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[crl_ext]
# Extension for CRLs (man x509v3_config).
authorityKeyIdentifier=keyid:always
EOF
}

# Create OpenSSL Client Config files
function f_create_openssl_registry_conf {
cat << EOF > conf/openssl-registry.conf
#### Mirror Registry ####
# OpenSSL root CA configuration file.
[req]
# Options for the req tool (man req).
default_bits = 2048
distinguished_name = req_distinguished_name
string_mask = utf8only

# SHA-1 is deprecated, so use SHA-2 instead.
default_md = sha256

# Extension to add when the -x509 option is used.
x509_extensions = v3_ca
req_extensions = v3_req

[v3_req]
# Extensions to add to a certificate request
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[req_distinguished_name]
# See <https://en.wikipedia.org/wiki/Certificate_signing_request>.
countryName = Country Name (2 letter code)
stateOrProvinceName = State or Province Name
localityName = Locality Name
0.organizationName = Organization Name
organizationalUnitName = Organizational Unit Name
commonName = Common Name
emailAddress = Email Address

# Optionally, specify some defaults.
countryName_default = "$OPENSSL_CLIENT_COUNTRY_NAME"
stateOrProvinceName_default = "$OPENSSL_CLIENT_STATE_NAME"
localityName_default = "$OPENSSL_CLIENT_LOCAL_NAME"
organizationalUnitName_default = "$OPENSSL_CLIENT_OU_NAME"
commonName_default = "$OPENSSL_CLIENT_COMMON_REGISTRY_NAME"

[alt_names]
DNS.1 = "$OPENSSL_CLIENT_COMMON_REGISTRY_NAME"
DNS.2 = "quay.io"
DNS.3 = "docker.io"
DNS.4 = "*.docker.io"
DNS.5 = "gcr.io"
DNS.6 = "*.gcr.io"
DNS.7 = "nvcr.io"
DNS.8 = "*.nvcr.io"
DNS.9 = "elastic.co"
DNS.10 = "*.elastic.co"
DNS.11 = "*.redhat.io"
DNS.12 = "*.redhat.com"
DNS.13 = "*.connect.redhat.com"
DNS.14 = "devfile.io"
DNS.15 = "*.devfile.io"
DNS.16 = "ghcr.io"
DNS.17 = "*.ghcr.io"
DNS.18 = "gitlab.com"
DNS.19 = "*.gitlab.com"
DNS.20 = "access.redhat.com"
DNS.21 = "*.access.redhat.com"
DNS.22 = "k8s.io"
DNS.23 = "*.k8s.io"

[v3_ca]
# Extensions for a typical CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:TRUE
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[v3_intermediate_ca]
# Extensions for a typical intermediate CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:TRUE, pathlen:0
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[server_cert]
# Extensions for server certificates (man x509v3_config).
basicConstraints = CA:TRUE
nsCertType = server
nsComment = "OpenSSL Generated Server Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer:always
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[crl_ext]
# Extension for CRLs (man x509v3_config).
authorityKeyIdentifier=keyid:always
EOF
}

# Create OpenSSL Client Config files
function f_create_openssl_router_conf {
cat << EOF > conf/openssl-router.conf
#### Router ####
# OpenSSL root CA configuration file.
[req]
# Options for the req tool (man req).
default_bits = 2048
distinguished_name = req_distinguished_name
string_mask = utf8only

# SHA-1 is deprecated, so use SHA-2 instead.
default_md = sha256

# Extension to add when the -x509 option is used.
x509_extensions = v3_ca
req_extensions = v3_req

[v3_req]
# Extensions to add to a certificate request
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[req_distinguished_name]
# See <https://en.wikipedia.org/wiki/Certificate_signing_request>.
countryName = Country Name (2 letter code)
stateOrProvinceName = State or Province Name
localityName = Locality Name
0.organizationName = Organization Name
organizationalUnitName = Organizational Unit Name
commonName = Common Name
emailAddress = Email Address

# Optionally, specify some defaults.
countryName_default = "$OPENSSL_CLIENT_COUNTRY_NAME"
stateOrProvinceName_default = "$OPENSSL_CLIENT_STATE_NAME"
localityName_default = "$OPENSSL_CLIENT_LOCAL_NAME"
organizationalUnitName_default = "$OPENSSL_CLIENT_OU_NAME"
commonName_default = "$OPENSSL_CLIENT_COMMON_ROUTE_NAME"

[alt_names]
DNS.1 = "$OPENSSL_CLIENT_COMMON_ROUTE_NAME"

[v3_ca]
# Extensions for a typical CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:TRUE
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[v3_intermediate_ca]
# Extensions for a typical intermediate CA (man x509v3_config).
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:TRUE, pathlen:0
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[server_cert]
# Extensions for server certificates (man x509v3_config).
basicConstraints = CA:TRUE
nsCertType = server
nsComment = "OpenSSL Generated Server Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer:always
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[crl_ext]
# Extension for CRLs (man x509v3_config).
authorityKeyIdentifier=keyid:always
EOF
}

# Create RootCA
function f_create_rootca {
  # Check workdir
  f_check_workdir

  # Check OpenSSL Config
  f_check_openssl_conf

  # Create RootCA key
  openssl genrsa -aes256 -out $ROOTCA_KEY -passout pass:$CERT_PASS 2048

  # Create self-signed
  # Hash: -sha256, -sha384, -sha512
  openssl req -config $OPENSSL_ROOTCA_CONF \
  -batch -new -x509 -days $ROOTCA_DAYS -sha256 -extensions v3_ca \
  -out $ROOTCA  -key $ROOTCA_KEY -passin pass:$CERT_PASS

  # Check RootCA
  echo
  echo "- RootCA"
  openssl x509 -noout -text -in $ROOTCA
}

# Create client certificates
function f_create_client_all {
  # Check workdir
  f_check_workdir

  # Check OpenSSL Config
  f_check_openssl_conf

  # Check RootCA certificates
  f_check_rootca

  # Mirror Registry
  # Create RSA key pair
  for i in ${CLIENT_NAME}; do
    openssl genrsa -out client/$i/$i.key -passout pass:$CERT_PASS 2048;
  done

  # Remove Passphrase from key
  for i in ${CLIENT_NAME}; do
    cp client/$i/$i.key client/$i/$i.enc
    openssl rsa -in client/$i/$i.enc -out client/$i/$i.key -passin pass:$CERT_PASS;
  done

  # Create CSR
  for i in ${CLIENT_NAME}; do
    openssl req -new -batch -sha256 \
    -key client/$i/$i.key \
    -out client/$i/$i.csr \
    -passin pass:$CERT_PASS \
    -config conf/openssl-$i.conf;
  done

  # Create SSL
  for i in ${CLIENT_NAME}; do
    openssl x509 -sha256 -req -extensions v3_req -days $ROOTCA_DAYS \
    -in client/$i/$i.csr -out client/$i/$i.crt -extfile conf/openssl-$i.conf \
    -CAcreateserial -CA $ROOTCA -CAkey $ROOTCA_KEY -passin pass:$CERT_PASS
  done

  # Check Certificates
  for i in ${CLIENT_NAME}; do
    echo
    echo "- Cert: $i"
    openssl x509 -noout -text -in client/$i/$i.crt;
  done

  # Check Certificates
  for i in ${CLIENT_NAME}; do
    echo
    echo "- Verify: $i"
    openssl verify -CAfile $ROOTCA client/$i/$i.crt;
  done
}

# Print help
function f_help {
  echo "Usage: $ARG_0 [Options]"
  echo
  echo "- Options"
  echo "a,  all         : Create RootCA, Client and Update CA Trust"
  echo "c,  client      : Create Client Certificates"
  echo "r,  root        : Create RootCA Certificates"
  echo "u,  update      : Update CA Trust"
  echo "h,  help        : Print help"
  echo
}

# Main
ARG_0="$0"
ARG_1="$1"
ARG_2="$2"

case ${ARG_1} in
  a|all)
    f_create_rootca
    f_create_client_all
    f_update_ca_trust
  ;;

  r|root)
    f_create_rootca
  ;;

  c|client)
    f_create_client_all
  ;;

  u|update)
    f_update_ca_trust
  ;;

  *|h|help)
    f_help
  ;;
esac
