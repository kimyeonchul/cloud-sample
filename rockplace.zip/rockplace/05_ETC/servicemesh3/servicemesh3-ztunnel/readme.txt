oc label ns bookinfo istio.io/use-waypoint=bookinfo-waypoint --overwrite
# 또는 외부 → ingressgateway → (waypoint 경유) → 서비스 형태
# oc label service productpage -n bookinfo istio.io/ingress-use-waypoint=true --overwrite
