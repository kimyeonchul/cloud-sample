#!/bin/sh
URL="https://bookinfo.apps.ext.goe.go.kr/productpage"

while :; do
  curl -ksS -o /dev/null -w "%{http_code}\n" "$URL"
  sleep 0.2
done

