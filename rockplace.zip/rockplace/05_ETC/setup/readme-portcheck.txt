ssh core@worker1 'bash -s -- bastion.ext.goe.go.kr' < ocp-port-worker-check.sh

ssh core@master1 'bash -s -- bastion.ext.goe.go.kr master1.ext.goe.go.kr,master2.ext.goe.go.kr,master3.ext.goe.go.kr' < ocp-port-master-check.sh

