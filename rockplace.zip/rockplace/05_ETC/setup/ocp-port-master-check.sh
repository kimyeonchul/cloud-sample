#!/usr/bin/env bash
set -euo pipefail

# Run on MASTER node.
# Usage:
#   ./ocp-port-master-check.sh <LB_OR_BASTION_HOST> <MASTER_PEERS_CSV> [DNS_HOST] [REGISTRY_HOST] [NTP_HOST]
# Example:
#   ./ocp-port-master-check.sh bastion.ext.goe.go.kr master1,master2,master3 bastion.ext.goe.go.kr bastion.ext.goe.go.kr bastion.ext.goe.go.kr

LB="${1:-}"
PEERS_CSV="${2:-}"
DNS="${3:-}"
REG="${4:-}"
NTP="${5:-}"

if [[ -z "$LB" || -z "$PEERS_CSV" ]]; then
  echo "Usage: $0 <LB_OR_BASTION_HOST> <MASTER_PEERS_CSV> [DNS_HOST] [REGISTRY_HOST] [NTP_HOST]" >&2
  exit 2
fi

DNS="${DNS:-$LB}"
REG="${REG:-$LB}"
NTP="${NTP:-$LB}"

IFS=',' read -r -a PEERS <<< "$PEERS_CSV"

have() { command -v "$1" >/dev/null 2>&1; }

NC_BIN="${NC_BIN:-nc}"
TIMEOUT_SEC="${TIMEOUT_SEC:-2}"

# ---- Description map -------------------------------------------------------
desc() {
  local proto="$1" port="$2"
  case "${proto}/${port}" in
    tcp/6443)  echo "Master API" ;;
    tcp/22623) echo "Machine Config" ;;
    tcp/80)    echo "Router (http)" ;;
    tcp/443)   echo "Router (https)" ;;
    tcp/1936)  echo "Metrics" ;;
    tcp/53)    echo "DNS" ;;
    tcp/5000)  echo "Mirror Registry" ;;
    tcp/2379)  echo "ETCD Client" ;;
    tcp/2380)  echo "ETCD Server Peer" ;;
    udp/123)   echo "NTP" ;;
    udp/4789)  echo "OpenShift SDN - VXLAN/Geneve" ;;
    udp/6081)  echo "OVN-Kubernetes - VXLAN/Geneve" ;;
    *)         echo "-" ;;
  esac
}

classify_nc_tcp() {
  local out="$1"
  if echo "$out" | grep -qiE "Connected to|succeeded|open"; then
    echo "OPEN"
  elif echo "$out" | grep -qiE "refused"; then
    echo "REFUSED"
  elif echo "$out" | grep -qiE "timed out|timeout"; then
    echo "TIMEOUT"
  elif echo "$out" | grep -qiE "Name or service not known|Temporary failure in name resolution|no address associated"; then
    echo "DNS_FAIL"
  elif echo "$out" | grep -qiE "Network is unreachable|No route to host|unreachable"; then
    echo "UNREACHABLE"
  else
    echo "FAIL"
  fi
}

tcp_check() {
  local host="$1" port="$2"
  local out st d
  out="$("$NC_BIN" -z -v -w "$TIMEOUT_SEC" "$host" "$port" 2>&1 || true)"
  st="$(classify_nc_tcp "$out")"
  d="$(desc tcp "$port")"
  printf "tcp  %-24s %-5s %-30s : %-10s\n" "$host" "$port" "$d" "$st"
  if [[ "$st" != "OPEN" ]]; then
    echo "$out" | sed 's/^/    /' | sed '/^\s*$/d'
  fi
}

udp_check_nmap() {
  local host="$1" ports_csv="$2"
  nmap -Pn -n -sU -p "$ports_csv" --host-timeout 20s "$host" 2>/dev/null \
    | awk 'BEGIN{in=0}
           /^PORT[ \t]+STATE[ \t]+SERVICE/{in=1; next}
           in==1 && $0 ~ /^[0-9]+\/udp/ {print}'
}

udp_best_effort() {
  local host="$1" port="$2"
  local d
  d="$(desc udp "$port")"
  if echo -n "" | "$NC_BIN" -u -w "$TIMEOUT_SEC" "$host" "$port" >/dev/null 2>&1; then
    printf "udp  %-24s %-5s %-30s : SENT (best-effort)\n" "$host" "$port" "$d"
  else
    printf "udp  %-24s %-5s %-30s : FAIL_SEND (best-effort)\n" "$host" "$port" "$d"
  fi
}

echo "== OCP Port Precheck (MASTER) =="
echo "Host  : $(hostname -f 2>/dev/null || hostname)"
echo "User  : $(id -un) (uid=$(id -u))"
echo "LB    : $LB"
echo "DNS   : $DNS"
echo "REG   : $REG"
echo "NTP   : $NTP"
echo "PEERS : ${PEERS[*]}"
echo

echo "-- To LB/DNS/Registry (TCP) --"
tcp_check "$LB" 6443
tcp_check "$LB" 22623
tcp_check "$LB" 80
tcp_check "$LB" 443
tcp_check "$LB" 1936
tcp_check "$DNS" 53
tcp_check "$REG" 5000

echo
echo "-- NTP (UDP) --"
if have nmap; then
  echo "udp  123   $(desc udp 123)"
  udp_check_nmap "$NTP" "123" | sed 's/^/    /'
else
  udp_best_effort "$NTP" 123
fi

echo
echo "-- Master <-> Master (ETCD TCP) --"
self_fqdn="$(hostname -f 2>/dev/null || hostname)"
self_short="$(hostname -s 2>/dev/null || hostname)"

for h in "${PEERS[@]}"; do
  [[ -z "$h" ]] && continue
  if [[ "$h" == "$self_fqdn" || "$h" == "$self_short" ]]; then
    continue
  fi
  tcp_check "$h" 2379
  tcp_check "$h" 2380
done

echo
echo "-- Overlay (UDP) to peers --"
if have nmap; then
  for h in "${PEERS[@]}"; do
    [[ -z "$h" ]] && continue
    echo "udp  ${h}  4789,6081  (nmap -sU) : $(desc udp 4789) / $(desc udp 6081)"
    udp_check_nmap "$h" "4789,6081" | sed 's/^/    /'
  done
else
  for h in "${PEERS[@]}"; do
    [[ -z "$h" ]] && continue
    udp_best_effort "$h" 4789
    udp_best_effort "$h" 6081
  done
fi

