#!/usr/bin/env bash
set -euo pipefail

# Run on the VM that should have ports open (LB/DNS/Registry/API VIP host, etc.)

TCP_PORTS=(1936 6443 22623 2379 2380 4789 6081 53 123 80 443 5000)
UDP_PORTS=(4789 6081 500 4500)

have() { command -v "$1" >/dev/null 2>&1; }

if ! have ss; then
  echo "ERROR: ss not found. Install iproute (iproute2)." >&2
  exit 1
fi

show_listeners() {
  local proto="$1" port="$2"
  if [[ "$proto" == "tcp" ]]; then
    ss -H -lntp "sport = :$port" 2>/dev/null || true
  else
    ss -H -lnup "sport = :$port" 2>/dev/null || true
  fi
}

check_port() {
  local proto="$1" port="$2"
  local out
  out="$(show_listeners "$proto" "$port")"
  if [[ -n "$out" ]]; then
    printf "%-4s %-5s : IN_USE (listening)\n" "$proto" "$port"
    echo "$out" | sed 's/^/    /'
  else
    printf "%-4s %-5s : FREE (no listener)\n" "$proto" "$port"
  fi
}

echo "== OCP Port Precheck (SERVER listener/process check) =="
echo "Host : $(hostname -f 2>/dev/null || hostname)"
echo "User : $(id -un) (uid=$(id -u))"
echo

echo "-- TCP --"
for p in "${TCP_PORTS[@]}"; do check_port tcp "$p"; done

echo
echo "-- UDP --"
for p in "${UDP_PORTS[@]}"; do check_port udp "$p"; done

