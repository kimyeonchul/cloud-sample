#!/usr/bin/env bash
set -euo pipefail

LB="${1:-}"
DNS="${2:-}"
REG="${3:-}"
NTP="${4:-}"

if [[ -z "$LB" ]]; then
  echo "Usage: $0 <LB_OR_BASTION_HOST> [DNS_HOST] [REGISTRY_HOST] [NTP_HOST]" >&2
  exit 2
fi
DNS="${DNS:-$LB}"
REG="${REG:-$LB}"
NTP="${NTP:-$LB}"

have() { command -v "$1" >/dev/null 2>&1; }

NC_BIN="${NC_BIN:-nc}"
TIMEOUT_SEC="${TIMEOUT_SEC:-2}"
DNS_TEST_NAME="${DNS_TEST_NAME:-$DNS}"

desc() {
  local proto="$1" port="$2"
  case "${proto}/${port}" in
    tcp/6443)  echo "Master API" ;;
    tcp/22623) echo "Machine Config" ;;
    tcp/80)    echo "Router (http)" ;;
    tcp/443)   echo "Router (https)" ;;
    tcp/1936)  echo "Metrics" ;;
    tcp/53)    echo "DNS (TCP)" ;;
    tcp/5000)  echo "Mirror Registry" ;;
    udp/53)    echo "DNS (UDP)" ;;
    udp/123)   echo "NTP (UDP)" ;;
    *)         echo "-" ;;
  esac
}

classify_nc_tcp() {
  local out="$1"
  if echo "$out" | grep -qiE "Connected to|succeeded|open"; then
    echo "OPEN"
  elif echo "$out" | grep -qiE "refused"; then
    echo "REFUSED"
  elif echo "$out" | grep -qiE "timed out|timeout"; then
    echo "TIMEOUT"
  elif echo "$out" | grep -qiE "Name or service not known|Temporary failure in name resolution|no address associated"; then
    echo "DNS_FAIL"
  elif echo "$out" | grep -qiE "Network is unreachable|No route to host|unreachable"; then
    echo "UNREACHABLE"
  else
    echo "FAIL"
  fi
}

tcp_check() {
  local host="$1" port="$2"
  local out st d
  out="$("$NC_BIN" -z -v -w "$TIMEOUT_SEC" "$host" "$port" 2>&1 || true)"
  st="$(classify_nc_tcp "$out")"
  d="$(desc tcp "$port")"
  printf "tcp  %-5s %-30s -> %-24s : %-10s\n" "$port" "$d" "$host" "$st"
  if [[ "$st" != "OPEN" ]]; then
    echo "$out" | sed 's/^/    /' | sed '/^\s*$/d'
  fi
}

udp_dns_verify() {
  local dns="$1"
  local d out status
  d="$(desc udp 53)"

  if ! have dig; then
    printf "udp  %-5s %-30s -> %-24s : SKIP (dig not found)\n" "53" "$d" "$dns"
    return
  fi

  # 도메인/zone 의존 제거: CH class의 version.bind TXT 질의
  # 응답이 오면(REFUSED 포함) status 라인이 존재함
  out="$(dig @"$dns" version.bind TXT CH +udp +time="$TIMEOUT_SEC" +tries=1 2>/dev/null || true)"

  # status 추출 (NOERROR, REFUSED, SERVFAIL, NXDOMAIN 등)
  status="$(echo "$out" | awk -F'[:, ]+' '/status:/{for(i=1;i<=NF;i++) if($i=="status") print $(i+1)}' | head -n1)"

  if [[ -n "$status" ]]; then
    printf "udp  %-5s %-30s -> %-24s : PASS (dig/udp status=%s)\n" "53" "$d" "$dns" "$status"
  else
    printf "udp  %-5s %-30s -> %-24s : FAIL (no dig/udp response)\n" "53" "$d" "$dns"

    # 참고: TCP로는 응답이 오는지 확인(UDP만 막힘/경로 문제 분리)
    if dig @"$dns" version.bind TXT CH +tcp +time="$TIMEOUT_SEC" +tries=1 >/dev/null 2>&1; then
      echo "    note: dig/tcp는 응답됨(UDP 경로/정책 확인 필요)."
    fi
  fi
}


udp_ntp_verify() {
  local ntp="$1"
  local d
  d="$(desc udp 123)"

  if ! have chronyc; then
    printf "udp  %-5s %-30s -> %-24s : SKIP (chronyc not found)\n" "123" "$d" "$ntp"
    return
  fi

  if ! chronyc -n tracking >/dev/null 2>&1; then
    printf "udp  %-5s %-30s -> %-24s : FAIL (chrony not healthy)\n" "123" "$d" "$ntp"
    return
  fi

  local ip=""
  ip="$(getent ahostsv4 "$ntp" 2>/dev/null | awk 'NR==1{print $1}')"
  if [[ -z "$ip" ]]; then
    ip="$(getent hosts "$ntp" 2>/dev/null | awk 'NR==1{print $1}')"
  fi

  if [[ -n "$ip" ]] && chronyc -n sources 2>/dev/null | awk '{print $2}' | grep -qx "$ip"; then
    printf "udp  %-5s %-30s -> %-24s : PASS (chrony uses %s)\n" "123" "$d" "$ntp" "$ip"
  else
    local ref=""
    ref="$(chronyc -n tracking 2>/dev/null | awk -F': ' '/^Reference ID/{print $2}' | awk '{print $2}' | tr -d '()')"
    if [[ -n "$ref" ]] && [[ -n "$ip" ]] && [[ "$ref" == "$ip" ]]; then
      printf "udp  %-5s %-30s -> %-24s : PASS (tracking ref=%s)\n" "123" "$d" "$ntp" "$ref"
    else
      printf "udp  %-5s %-30s -> %-24s : WARN (chrony ok; target not confirmed)\n" "123" "$d" "$ntp"
    fi
  fi
}

udp_nmap_hint() {
  local host="$1" ports_csv="$2"
  if have nmap; then
    echo "udp  ports     (nmap -sU) -> ${host} : ${ports_csv}"
    nmap -Pn -n -sU -p "$ports_csv" --host-timeout 20s "$host" 2>/dev/null \
      | awk 'BEGIN{in=0}
             /^PORT[ \t]+STATE[ \t]+SERVICE/{in=1; next}
             in==1 && $0 ~ /^[0-9]+\/udp/ {print}' | sed 's/^/    /'
    echo "    note: UDP open|filtered는 허용 또는 무응답(드랍)일 수 있음."
  fi
}

echo "== OCP Port Precheck (WORKER) =="
echo "Host : $(hostname -f 2>/dev/null || hostname)"
echo "User : $(id -un) (uid=$(id -u))"
echo "LB   : $LB"
echo "DNS  : $DNS"
echo "REG  : $REG"
echo "NTP  : $NTP"
echo

echo "-- TCP CONNECT --"
tcp_check "$LB" 6443
tcp_check "$LB" 22623
tcp_check "$LB" 80
tcp_check "$LB" 443
tcp_check "$LB" 1936
tcp_check "$DNS" 53
tcp_check "$REG" 5000

echo
echo "-- UDP VERIFY (service-based) --"
udp_dns_verify "$DNS"
udp_ntp_verify "$NTP"
udp_nmap_hint "$DNS" "53"
udp_nmap_hint "$NTP" "123"

