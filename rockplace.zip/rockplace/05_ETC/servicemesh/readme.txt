##########



### bookinfo image ###
podman pull docker.io/istio/examples-bookinfo-details-v1:1.20.3
podman pull docker.io/istio/examples-bookinfo-ratings-v1:1.20.3
podman pull docker.io/istio/examples-bookinfo-reviews-v1:1.20.3
podman pull docker.io/istio/examples-bookinfo-reviews-v2:1.20.3
podman pull docker.io/istio/examples-bookinfo-reviews-v3:1.20.3
podman pull docker.io/istio/examples-bookinfo-productpage-v1:1.20.3

podman tag docker.io/istio/examples-bookinfo-details-v1:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-details-v1:1.20.3
podman tag docker.io/istio/examples-bookinfo-ratings-v1:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-ratings-v1:1.20.3
podman tag docker.io/istio/examples-bookinfo-reviews-v1:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v1:1.20.3
podman tag docker.io/istio/examples-bookinfo-reviews-v2:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v2:1.20.3
podman tag docker.io/istio/examples-bookinfo-reviews-v3:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v3:1.20.3
podman tag docker.io/istio/examples-bookinfo-productpage-v1:1.20.3 registry.ext.goe.go.kr:5000/istio/examples-bookinfo-productpage-v1:1.20.3

podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-details-v1:1.20.3
podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-ratings-v1:1.20.3
podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v1:1.20.3
podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v2:1.20.3
podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-reviews-v3:1.20.3
podman push registry.ext.goe.go.kr:5000/istio/examples-bookinfo-productpage-v1:1.20.3

podman save -o examples-bookinfo-details-v1-1.20.3.tar \
  docker.io/istio/examples-bookinfo-details-v1:1.20.3
podman save -o examples-bookinfo-ratings-v1-1.20.3.tar \
  docker.io/istio/examples-bookinfo-ratings-v1:1.20.3
podman save -o examples-bookinfo-reviews-v1-1.20.3.tar \
  docker.io/istio/examples-bookinfo-reviews-v1:1.20.3
podman save -o examples-bookinfo-reviews-v2-1.20.3.tar \
  docker.io/istio/examples-bookinfo-reviews-v2:1.20.3
podman save -o examples-bookinfo-reviews-v3-1.20.3.tar \
  docker.io/istio/examples-bookinfo-reviews-v3:1.20.3
podman save -o examples-bookinfo-productpage-v1-1.20.3.tar \
  docker.io/istio/examples-bookinfo-productpage-v1:1.20.3

podman load -i examples-bookinfo-details-v1-1.20.3.tar
podman load -i examples-bookinfo-productpage-v1-1.20.3.tar
podman load -i examples-bookinfo-ratings-v1-1.20.3.tar
podman load -i examples-bookinfo-reviews-v1-1.20.3.tar
podman load -i examples-bookinfo-reviews-v2-1.20.3.tar
podman load -i examples-bookinfo-reviews-v3-1.20.3.tar



### ose-oauth-proxy ###
podman pull registry.redhat.io/openshift4/ose-oauth-proxy:v4.9
podman tag registry.redhat.io/openshift4/ose-oauth-proxy:v4.9 registry.ext.goe.go.kr:5000/istio/ose-oauth-proxy:v4.9
podman push --remove-signatures registry.ext.goe.go.kr:5000/istio/ose-oauth-proxy:v4.9
podman save -o ose-oauth-proxy-v4.9.tar registry.redhat.io/openshift4/ose-oauth-proxy:v4.9
podman load -i ose-oauth-proxy-v4.9.tar



########## 
