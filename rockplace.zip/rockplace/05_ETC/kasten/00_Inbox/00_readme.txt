oc adm policy add-scc-to-user anyuid \
  -z prometheus-server \
  -n kasten-io

mkdir -p /data/nfs/kasten/catalog
mkdir -p /data/nfs/kasten/jobs
mkdir -p /data/nfs/kasten/logging
mkdir -p /data/nfs/kasten/metering
mkdir -p /data/nfs/kasten/prometheus

chmod -R 777 /data/nfs/kasten

oc patch consoles.operator.openshift.io cluster \
  --type=json \
  -p='[{"op":"add","path":"/spec/plugins/-","value":"veeam-kasten-console-plugin"}]'
