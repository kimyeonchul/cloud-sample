# Reference: https://hub.docker.com/r/nginxinc/nginx-unprivileged
# Reference: https://github.com/nginx/docker-nginx-unprivileged

# Pull the image from GitHub Container Registry.
podman pull ghcr.io/nginxinc/nginx-unprivileged:latest

# Save the image as a tar archive for offline transfer.
podman save -o nginx-unprivileged-latest.tar ghcr.io/nginxinc/nginx-unprivileged:latest

# Load the image on the air-gapped bastion server.
podman load -i nginx-unprivileged-latest.tar

# Tag the image for the internal registry.
podman tag ghcr.io/nginxinc/nginx-unprivileged:latest <internal_registry_url>:5000/nginxinc/nginx-unprivileged:latest

# Push the image to the internal registry.
podman push <internal_registry_url>:5000/nginxinc/nginx-unprivileged:latest
