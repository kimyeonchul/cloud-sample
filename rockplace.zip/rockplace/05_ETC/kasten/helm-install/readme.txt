curl -LO https://get.helm.sh/helm-v3.21.0-linux-amd64.tar.gz  
tar -xzf helm-v3.21.0-linux-amd64.tar.gz  
install -m 0755 linux-amd64/helm /usr/local/bin/helm  
helm version
