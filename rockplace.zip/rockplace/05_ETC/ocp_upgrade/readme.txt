
oc-mirror --config=isc_v2.yaml file:///data/image/operator_ocp_to_4.18.27/mirror-output --v2

oc-mirror --config isc_v2.yaml \
  --from file:///data/image/operator_ocp_to_4.18.27/mirror-output \
  docker://registry.ext.goe.go.kr:5000/operator_ocp_to_4.18.27 --v2


oc apply -f /data/image/ocp_4.15.55/mirror-output/working-dir/cluster-resources/signature-configmap.json

oc adm release info registry.ext.goe.go.kr:5000/openshift/release-images:4.15.55-x86_64 | grep Pull


oc adm upgrade --allow-explicit-upgrade --to-image=registry.ext.goe.go.kr:5000/openshift/release-images@sha256:3ff7652a165409a368a7cdc748c95efc17db0761d467cc85fb355cce14643602 --allow-upgrade-with-warnings=true

