#!/bin/bash

OUT="ocp-upgrade-precheck.txt"

echo "# OpenShift 업그레이드 전 확인 사항" > "$OUT"
echo "수집 일시: $(date)" >> "$OUT"

echo -e "\n\n## 현재 OCP 버전" >> "$OUT"
oc get clusterversion -o yaml >> "$OUT"

echo -e "\n\n## 업그레이드 가능 경로" >> "$OUT"
oc adm upgrade >> "$OUT" 2>&1

echo -e "\n\n## 전체 노드 정보" >> "$OUT"
oc get node -o wide >> "$OUT"

echo -e "\n\n## Operator 구독 정보" >> "$OUT"
oc get subscription -A >> "$OUT"

echo -e "\n\n## CSV 상태 요약, Copied 제외" >> "$OUT"
oc get csv -A -o json \
  | jq -r '.items[]
    | select(.status.reason != "Copied")
    | [.metadata.namespace, .metadata.name, .spec.displayName, .spec.version, .status.phase, .status.reason]
    | @tsv' \
  | column -t >> "$OUT"

echo -e "\n\n## ICSP" >> "$OUT"
oc get imagecontentsourcepolicy -o yaml >> "$OUT"

echo -e "\n\n## IDMS" >> "$OUT"
oc get idms -o yaml >> "$OUT"

echo -e "\n\n## ITMS" >> "$OUT"
oc get itms -o yaml >> "$OUT"

echo -e "\n\n## Bastion 디스크 사용량" >> "$OUT"  
df -h >> "$OUT" 2>&1

echo "완료: $OUT"
