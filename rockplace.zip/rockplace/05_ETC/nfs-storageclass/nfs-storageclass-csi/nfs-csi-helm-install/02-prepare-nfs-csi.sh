#!/bin/bash

# Helm 차트의 원본 이미지와 values-registry.yaml에 정의된 내부 이미지를 비교하여
# 원본 이미지를 Pull한 후 동일한 대상 경로로 Tag 및 Push합니다.
set -euo pipefail

# 필요 시 실행 명령 앞에서 환경변수로 값을 변경할 수 있습니다.
# 예: TARGET_TLS_VERIFY=false bash 03-mirror-nfs-csi-images.sh
RELEASE_NAME="${RELEASE_NAME:-csi-driver-nfs}"
NAMESPACE="${NAMESPACE:-nfs-csi}"
VALUES_COMMON="${VALUES_COMMON:-values-common.yaml}"
VALUES_REGISTRY="${VALUES_REGISTRY:-values-registry.yaml}"
TARGET_TLS_VERIFY="${TARGET_TLS_VERIFY:-true}"
IMAGE_ARCH="${IMAGE_ARCH:-amd64}"

# 필수 명령어가 설치되어 있는지 확인합니다.
for REQUIRED_COMMAND in helm podman awk; do
  command -v "${REQUIRED_COMMAND}" >/dev/null 2>&1 || {
    echo "필수 명령어가 없습니다: ${REQUIRED_COMMAND}"
    exit 1
  }
done

# 현재 디렉터리에서 가장 최근에 저장된 NFS CSI Helm 차트를 선택합니다.
CHART_FILE="${CHART_FILE:-$(ls -1t csi-driver-nfs-*.tgz 2>/dev/null | head -n 1 || true)}"

if [[ -z "${CHART_FILE}" || ! -f "${CHART_FILE}" ]]; then
  echo "NFS CSI Helm 차트 파일을 찾을 수 없습니다."
  echo "CHART_FILE 환경변수 또는 csi-driver-nfs-*.tgz 파일을 확인해야 합니다."
  exit 1
fi

# 이미지 추출에 필요한 values 파일을 확인합니다.
for VALUES_FILE in "${VALUES_COMMON}" "${VALUES_REGISTRY}"; do
  if [[ ! -f "${VALUES_FILE}" ]]; then
    echo "필수 values 파일이 없습니다: ${VALUES_FILE}"
    exit 1
  fi
done

# 임시 렌더링 결과를 저장할 디렉터리를 생성합니다.
MIRROR_TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${MIRROR_TMP_DIR}"' EXIT

SOURCE_MANIFEST="${MIRROR_TMP_DIR}/source-manifest.yaml"
TARGET_MANIFEST="${MIRROR_TMP_DIR}/target-manifest.yaml"

# values-registry.yaml을 제외하여 원본 이미지 경로를 렌더링합니다.
helm template "${RELEASE_NAME}" "${CHART_FILE}" \
  -n "${NAMESPACE}" \
  -f "${VALUES_COMMON}" \
  > "${SOURCE_MANIFEST}"

# values-registry.yaml을 포함하여 내부 Registry 이미지 경로를 렌더링합니다.
helm template "${RELEASE_NAME}" "${CHART_FILE}" \
  -n "${NAMESPACE}" \
  -f "${VALUES_COMMON}" \
  -f "${VALUES_REGISTRY}" \
  > "${TARGET_MANIFEST}"

# 렌더링된 Kubernetes 리소스에서 컨테이너 이미지 경로를 추출합니다.
extract_images() {
  awk '
    /^[[:space:]]*image:[[:space:]]*/ {
      image = $0
      sub(/^[[:space:]]*image:[[:space:]]*/, "", image)
      sub(/[[:space:]]+#.*/, "", image)
      gsub(/"/, "", image)
      if (image != "") {
        print image
      }
    }
  ' "$1"
}

mapfile -t SOURCE_IMAGES < <(extract_images "${SOURCE_MANIFEST}")
mapfile -t TARGET_IMAGES < <(extract_images "${TARGET_MANIFEST}")

# 원본 이미지와 대상 이미지의 개수가 다르면 잘못된 매핑을 방지하기 위해 중단합니다.
if [[ "${#SOURCE_IMAGES[@]}" -eq 0 ]]; then
  echo "Helm 차트에서 컨테이너 이미지를 찾을 수 없습니다."
  exit 1
fi

if [[ "${#SOURCE_IMAGES[@]}" -ne "${#TARGET_IMAGES[@]}" ]]; then
  echo "원본 이미지와 대상 이미지 개수가 일치하지 않습니다."
  echo "원본: ${#SOURCE_IMAGES[@]}, 대상: ${#TARGET_IMAGES[@]}"
  exit 1
fi

# 현재 values-registry.yaml 기준 이미지 매핑을 출력합니다.
echo "사용 차트: ${CHART_FILE}"
echo "이미지 매핑:"

for INDEX in "${!SOURCE_IMAGES[@]}"; do
  printf '  %s -> %s\n' "${SOURCE_IMAGES[$INDEX]}" "${TARGET_IMAGES[$INDEX]}"
done

# 동일한 대상 Registry에 여러 번 로그인하지 않도록 상태를 저장합니다.
declare -A LOGGED_IN_REGISTRIES=()
declare -A PUSHED_IMAGES=()

for INDEX in "${!SOURCE_IMAGES[@]}"; do
  SOURCE_IMAGE="${SOURCE_IMAGES[$INDEX]}"
  TARGET_IMAGE="${TARGET_IMAGES[$INDEX]}"

  # 동일 이미지가 여러 Pod에 사용되는 경우 한 번만 전송합니다.
  if [[ -n "${PUSHED_IMAGES[${TARGET_IMAGE}]:-}" ]]; then
    continue
  fi

  # 원본과 대상 경로가 같으면 values-registry.yaml에서 미러 경로가 누락된 것입니다.
  if [[ "${SOURCE_IMAGE}" == "${TARGET_IMAGE}" ]]; then
    echo "내부 Registry 경로로 변경되지 않은 이미지가 있습니다: ${SOURCE_IMAGE}"
    echo "values-registry.yaml의 image 설정을 확인해야 합니다."
    exit 1
  fi

  TARGET_REGISTRY="${TARGET_IMAGE%%/*}"

  if [[ "${TARGET_REGISTRY}" == "${TARGET_IMAGE}" ]]; then
    echo "대상 이미지 경로에서 Registry 주소를 확인할 수 없습니다: ${TARGET_IMAGE}"
    exit 1
  fi

  # 대상 Registry에 로그인합니다. 최초 한 번만 사용자명과 비밀번호를 입력합니다.
  if [[ -z "${LOGGED_IN_REGISTRIES[${TARGET_REGISTRY}]:-}" ]]; then
    podman login \
      --tls-verify="${TARGET_TLS_VERIFY}" \
      "${TARGET_REGISTRY}"

    LOGGED_IN_REGISTRIES["${TARGET_REGISTRY}"]=1
  fi

  echo "원본 이미지 Pull: ${SOURCE_IMAGE}"
  podman pull \
    --arch "${IMAGE_ARCH}" \
    "${SOURCE_IMAGE}"

  echo "내부 이미지 Tag: ${TARGET_IMAGE}"
  podman tag "${SOURCE_IMAGE}" "${TARGET_IMAGE}"

  echo "내부 Registry Push: ${TARGET_IMAGE}"
  podman push \
    --tls-verify="${TARGET_TLS_VERIFY}" \
    "${TARGET_IMAGE}"

  PUSHED_IMAGES["${TARGET_IMAGE}"]=1
done

echo "NFS CSI 이미지 미러링이 완료되었습니다."
echo "02-install-nfs-csi.sh를 다시 실행하여 NFS CSI Pod를 재배포해야 합니다."
