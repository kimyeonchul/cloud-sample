#!/bin/bash

# 오류 발생 시 즉시 종료하고, 선언되지 않은 변수 사용을 차단합니다.
set -euo pipefail

# 설치할 Helm 버전과 Bastion 서버 아키텍처를 지정합니다.
# x86_64 서버는 linux-amd64를 사용합니다.
HELM_VERSION="v3.21.3"
HELM_ARCH="linux-amd64"

# Helm 설치 및 차트 버전 조회에 필요한 패키지를 설치합니다.
dnf install -y curl tar gzip jq

# Helm 설치 파일을 처리할 임시 디렉터리를 생성합니다.
HELM_TMP_DIR="$(mktemp -d)"

# 스크립트 종료 시 임시 디렉터리를 삭제합니다.
trap 'rm -rf "${HELM_TMP_DIR}"' EXIT

cd "${HELM_TMP_DIR}"

# Helm 바이너리 압축 파일과 SHA-256 체크섬 파일을 다운로드합니다.
curl -LO "https://get.helm.sh/helm-${HELM_VERSION}-${HELM_ARCH}.tar.gz"
curl -LO "https://get.helm.sh/helm-${HELM_VERSION}-${HELM_ARCH}.tar.gz.sha256sum"

# 다운로드한 압축 파일의 무결성을 확인합니다.
sha256sum -c "helm-${HELM_VERSION}-${HELM_ARCH}.tar.gz.sha256sum"

# Helm 바이너리를 추출하고 시스템 실행 경로에 설치합니다.
tar -xzf "helm-${HELM_VERSION}-${HELM_ARCH}.tar.gz"
install -m 0755 "${HELM_ARCH}/helm" /usr/local/bin/helm

# 기존 작업 디렉터리로 복귀합니다.
cd -

# Helm과 jq 설치 상태를 확인합니다.
helm version
jq --version



