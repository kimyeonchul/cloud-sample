#!/bin/bash

# 오류 발생 시 즉시 종료하고, 선언되지 않은 변수 사용을 차단합니다.
set -euo pipefail

# 필수 명령어가 설치되어 있는지 확인합니다.
command -v helm >/dev/null 2>&1 || {
  echo "helm 명령어가 없습니다. 01-install-helm.txt를 먼저 실행해야 합니다."
  exit 1
}

command -v jq >/dev/null 2>&1 || {
  echo "jq 명령어가 없습니다. 01-install-helm.txt를 먼저 실행해야 합니다."
  exit 1
}

command -v oc >/dev/null 2>&1 || {
  echo "oc 명령어가 없습니다. OpenShift CLI를 먼저 설치해야 합니다."
  exit 1
}

# 사용자 정의 Helm values 파일이 현재 디렉터리에 있는지 확인합니다.
for VALUES_FILE in values-common.yaml values-registry.yaml; do
  if [[ ! -f "${VALUES_FILE}" ]]; then
    echo "필수 파일이 없습니다: ${VALUES_FILE}"
    exit 1
  fi
done

# NFS CSI Driver Helm 저장소를 등록하거나 기존 정보를 갱신합니다.
helm repo add csi-driver-nfs \
  https://raw.githubusercontent.com/kubernetes-csi/csi-driver-nfs/master/charts \
  --force-update

# 등록된 Helm 저장소의 차트 목록을 갱신합니다.
helm repo update

# NFS CSI Driver 차트의 최신 버전을 조회합니다.
CHART_VERSION="$(
  helm search repo csi-driver-nfs/csi-driver-nfs \
    --versions \
    -o json |
  jq -r '.[0].version'
)"

# 조회 결과가 비어 있거나 null이면 설치를 중단합니다.
if [[ -z "${CHART_VERSION}" || "${CHART_VERSION}" == "null" ]]; then
  echo "NFS CSI Driver 차트 버전을 확인할 수 없습니다."
  exit 1
fi

# 다운로드할 차트 파일 이름을 구성합니다.
CHART_FILE="csi-driver-nfs-${CHART_VERSION}.tgz"

# 조회한 버전의 차트를 현재 디렉터리에 다운로드합니다.
helm pull csi-driver-nfs/csi-driver-nfs \
  --version "${CHART_VERSION}"

# values 파일을 적용하여 NFS CSI Driver를 설치하거나 업그레이드합니다.
helm upgrade --install csi-driver-nfs \
  "./${CHART_FILE}" \
  -n nfs-csi \
  --create-namespace \
  -f values-common.yaml \
  -f values-registry.yaml

# Controller와 Node ServiceAccount에 privileged SCC를 부여합니다.
oc adm policy add-scc-to-user privileged \
  -z csi-nfs-controller-sa \
  -n nfs-csi

oc adm policy add-scc-to-user privileged \
  -z csi-nfs-node-sa \
  -n nfs-csi

# 변경된 SCC 권한이 적용되도록 NFS CSI Pod를 재생성합니다.
oc delete pod -n nfs-csi --all

# Controller Deployment와 Node DaemonSet의 배포 완료를 대기합니다.
oc rollout status deployment/csi-nfs-controller \
  -n nfs-csi \
  --timeout=10m

oc rollout status daemonset/csi-nfs-node \
  -n nfs-csi \
  --timeout=10m

# 최종 설치 상태를 확인합니다.
oc get pods -n nfs-csi -o wide
oc get csidriver nfs.csi.k8s.io
oc get storageclass nfs-csi
helm list -n nfs-csi



