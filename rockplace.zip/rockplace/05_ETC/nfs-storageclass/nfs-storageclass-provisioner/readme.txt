##########


## 1. Pull Images on an Internet-Connected Server

# Pull the NFS Subdir External Provisioner image.
podman pull registry.k8s.io/sig-storage/nfs-subdir-external-provisioner:v4.0.2

# Pull the UBI Minimal image for NFS test pods.
podman pull registry.access.redhat.com/ubi9/ubi-minimal:latest


## 2. Save Images as Tar Archives

# Save the NFS Subdir External Provisioner image for offline transfer.
podman save -o nfs-subdir-external-provisioner-v4.0.2.tar \
  registry.k8s.io/sig-storage/nfs-subdir-external-provisioner:v4.0.2

# Save the UBI Minimal image for offline transfer.
podman save \
  -o ubi9-ubi-minimal-latest.tar \
  registry.access.redhat.com/ubi9/ubi-minimal:latest


## 3. Load Images on the Air-Gapped Bastion Server

# Load the NFS Subdir External Provisioner image.
podman load -i nfs-subdir-external-provisioner-v4.0.2.tar

# Load the UBI Minimal image.
podman load -i ubi9-ubi-minimal-latest.tar

# Verify that the images were loaded successfully.
podman images | egrep 'nfs-subdir-external-provisioner|ubi-minimal'


## 4. Tag Images for the Internal Registry

# Tag the NFS Subdir External Provisioner image for the internal registry.
podman tag \
  registry.k8s.io/sig-storage/nfs-subdir-external-provisioner:v4.0.2 \
  <internal_registry_url>:5000/sig-storage/nfs-subdir-external-provisioner:v4.0.2

# Tag the UBI Minimal image for the internal registry.
podman tag \
  registry.access.redhat.com/ubi9/ubi-minimal:latest \
  <internal_registry_url>:5000/ubi9/ubi-minimal:latest


## 5. Push Images to the Internal Registry

# Log in to the internal registry.
podman login <internal_registry_url>:5000

# Push the NFS Subdir External Provisioner image to the internal registry.
podman push \
  <internal_registry_url>:5000/sig-storage/nfs-subdir-external-provisioner:v4.0.2

# Push the UBI Minimal image to the internal registry.
podman push --remove-signatures \
  <internal_registry_url>:5000/ubi9/ubi-minimal:latest


## 6. Push Images When Using a Self-Signed Registry Certificate

# Log in to the internal registry without TLS certificate verification.
podman login <internal_registry_url>:5000 --tls-verify=false

# Push the NFS Subdir External Provisioner image without TLS certificate verification.
podman push --tls-verify=false \
  <internal_registry_url>:5000/sig-storage/nfs-subdir-external-provisioner:v4.0.2

# Push the UBI Minimal image without TLS certificate verification.
podman push --tls-verify=false --remove-signatures \
  <internal_registry_url>:5000/ubi9/ubi-minimal:latest


## 7. Verify NFS PVC Operation

# Create a test file on the mounted NFS volume.
oc -n default exec -it nfs-test-pod -- sh -c 'echo "hello nfs" > /data/hello.txt'

# Write the current time to the mounted NFS volume.
oc -n default exec -it nfs-test-pod -- sh -c 'date > /data/time.txt'

# Check the files inside the mounted path.
oc -n default exec -it nfs-test-pod -- sh -c 'ls -l /data'

# Check the files on the NFS server export path.
ls -l /data/nfs/default-test-nfs-pvc-pvc-...


##########
