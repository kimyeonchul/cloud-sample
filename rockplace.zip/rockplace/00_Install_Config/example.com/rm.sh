rm -rf .openshift_install* *.ign *.json auth/ openshift/ manifests/
rm -rf /root/.cache/openshift-installer/ .clusterapi_output
rm -rf terraform* tls/
