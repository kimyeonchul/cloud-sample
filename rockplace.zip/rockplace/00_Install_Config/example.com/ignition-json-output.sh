#!/bin/bash

if [[ ! -e "$(which jq)" ]]; then
  echo "[!] Install Package"
  echo "# yum install jq"

else
  for ignition in {bootstrap,master,worker}; do
    cat $ignition.ign | jq . > ../../01_Instance_Setting/rhcos/ignition/$ignition.ign;
  done
fi
