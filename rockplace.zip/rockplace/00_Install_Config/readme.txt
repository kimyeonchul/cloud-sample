#####

openshift-install create ignition-configs --log-level debug

openshift-install wait-for bootstrap-complete --dir=. --log-level=debug


curl http://172.30.1.221:81/rhcos/ignition/bootstrap.ign


curl -sk --max-time 5 -o /dev/null -w "HTTP=%{http_code}\n" https://api-int.ext.goe.go.kr:22623/healthz
# HTTP=200

curl -sk --max-time 5 -o /dev/null -w "HTTP=%{http_code}\n" https://api.ext.goe.go.kr:6443/readyz
# HTTP=200


mkdir $HOME/.kube
cp /data/rockplace/00_Install_Config/auth/kubeconfig $HOME/.kube/config


for i in `oc get csr |grep Pending |awk '{print $1}'` ; do oc adm certificate approve $i; done

oc completion bash > /etc/bash_completion.d/oc
kubectl completion bash > /etc/bash_completion.d/kubectl
source /root/.bashrc


sudo egrep -n 'stats (enable|uri|auth)|listen stats|frontend stats|bind .*:([0-9]+)' /etc/haproxy/haproxy.cfg
sudo ss -lntp | grep haproxy

http://192.168.1.221:1936/

oc patch schedulers.config.openshift.io cluster --type=merge -p '{"spec":{"mastersSchedulable":false}}'



#####
