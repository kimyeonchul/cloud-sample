{
  "ignition": {
    "config": {
      "merge": [
        {
          "source": "http://192.168.15.1:81/rhcos/ignition/bootstrap.ign",
          "verification": {}
        }
      ]
    },
    "timeouts": {},
    "version": "3.4.0"
  },
  "networkd": {},
  "passwd": {},
  "storage": {},
  "systemd": {}
}

