#!/bin/bash

OCP_VERSION=""
QUAY_VERSION=`curl https://mirror.openshift.com/pub/openshift-v4/clients/mirror-registry/ | grep -E "span class=\"name\"" | sed -e "s,<\/\?span[^>]*>,,g" | sort -V | tail -n1 | tr -d " "`

if [[ -z "$OCP_VERSION" ]]; then
    OCP_VERSION="stable"
fi

curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/butane/latest/butane -O
curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/openshift-client-linux.tar.gz -O
curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/openshift-install-linux.tar.gz -O
curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/oc-mirror.tar.gz -O
curl -sL https://mirror.openshift.com/pub/openshift-v4/clients/mirror-registry/${QUAY_VERSION}/mirror-registry.tar.gz -O

for i in {openshift-client-linux.tar.gz,openshift-install-linux.tar.gz,oc-mirror.tar.gz};do tar xzvf $i;done
chmod a+x butane openshift-install kubectl oc oc-mirror

if [[ $OCP_VERSION == "stable" ]]; then
    OCP_VERSION=`./oc version | awk '{if($1 ~ "Client") {print $3}}'`
    OCP_MAJOR=stable-`./oc version | awk '{if($1 ~ "Client") {print $3}}' | cut -d "." -f -2`
else
    OCP_MAJOR=`./oc version | awk '{if($1 ~ "Client") {print $3}}' | cut -d "." -f -2`
fi

sed -i "s,OCP_VERSION,$OCP_VERSION,g" /data/rockplace/04_Release_Config/imageset-release.yaml
sed -i "s,OCP_MAJOR,$OCP_MAJOR,g" /data/rockplace/04_Release_Config/imageset-release.yaml
