# Step 1. Create directory
[root@bastion ~]# mkdir -p /etc/security/limits.d/

# Step 2. Copy config file
[root@bastion ~]# cp openfile-max-process.conf /etc/security/limits.d/

# Step 3. Apply Sysctl or System Reboot
[root@bastion ~]# sysctl -p
or
[root@bastion ~]# reboot
