#!/bin/bash

podman stop mirror-registry; podman rm mirror-registry
podman run --privileged -d -p 5000:5000 --name mirror-registry \
-v /data/mirror-registry:/var/lib/registry \
-v /data/mirror-registry/certs:/certs \
-e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/registry.crt \
-e REGISTRY_HTTP_TLS_KEY=/certs/registry.key \
registry.ocp4.local:5000/library/registry:2.8.1

podman generate systemd --name mirror-registry > /lib/systemd/system/container-mirror-registry.service
systemctl enable container-mirror-registry.service
