#!/bin/bash
QUAY_USERID="admin"
QUAY_PASSWD="admin1234"
QUAY_HOSTNAME="registry.ocp4.local:5000"
QUAY_STORAGE_NAME="quay-storage"
QUAY_PGSQL_STORAGE_NAME="quay-pg-storage"

# Directory
QUAY_CONF_DIR="/data/mirror-registry"

# SSL Directory
QUAY_SSL_CERT="/data/mirror-registry/certs/registry.crt"
QUAY_SSL_KEY="/data/mirror-registry/certs/registry.key"

# Install Mirror Registry
./mirror-registry install \
--initUser "${QUAY_USERID}" \
--initPassword "${QUAY_PASSWD}" \
--quayHostname "${QUAY_HOSTNAME}" \
--pgStorage "${QUAY_PGSQL_STORAGE_NAME}" \
--quayStorage "${QUAY_STORAGE_NAME}" \
--quayRoot "${QUAY_CONF_DIR}" \
--sslCert "${QUAY_SSL_CERT}" \
--sslKey "${QUAY_SSL_KEY}"
