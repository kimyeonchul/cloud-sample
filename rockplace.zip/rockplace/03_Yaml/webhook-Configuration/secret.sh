oc new-project sss1
oc create sa sss
oc adm policy add-scc-to-user privileged -z sss -n sss1
oc create secret generic webhook-tls   --from-file=tls.crt=tls.crt   --from-file=tls.key=tls.key   --from-file=ca.crt=ca.crt   -nsss1
