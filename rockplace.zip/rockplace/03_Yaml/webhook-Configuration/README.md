# WEBHOOK CONFIGURATION

Validating / Mutating Webhook 예시와 Python기반의 Webhook Server 코드를 제공합니다.  

## 0. 디렉터리 구조   

.  
├── 01_deployment.yml  
├── 02_validate.yml  
├── 03_mutate.yml  
├── 04_test-pod.yml  
├── app.py  
├── ca.crt  
├── kustomization.yml  
├── README.md  
├── secret.sh  
├── tls.crt  
└── tls.key  
  
0 directories, 11 files  


## 1. Secret 생성  
웹훅 서버의 서비스에 대한 인증서를 생성해야 합니다. 해당 인증서를 Python Webhook 서버의 SSL 인증에 사용합니다.  
- sh secret.sh  

  
## 2. kustomize apply   
Kustomization에 사전 정의된 Webhook Server , ConfigMap(Python Code), WebhookConfiguration을 생성합니다.  
- oc apply -k .  

