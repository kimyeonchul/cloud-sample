import http.server
import ssl
import json
import base64
import logging
from urllib.parse import urlparse

class AdmissionWebhookHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        # 요청 경로에서 쿼리 스트링 제거
        parsed_path = urlparse(self.path).path  
        logging.info(f"Received request: {parsed_path}")  # 요청 경로 로그 추가

        # 요청 본문 읽기
        content_length = int(self.headers.get('Content-Length', 0))
        request_body = self.rfile.read(content_length).decode('utf-8')

        try:
            request_data = json.loads(request_body)
            uid = request_data["request"]["uid"]

            if parsed_path == "/validate":
                response = self.validate_request(uid, request_data)
            elif parsed_path == "/mutate":
                response = self.mutate_request(uid, request_data)
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Not Found")
                return

            # JSON 응답 전송
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(response).encode("utf-8"))

        except Exception as e:
            logging.error(f"Error processing request: {e}")
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"Internal Server Error")

    def validate_request(self, uid, request_data):
        """Validate 요청 처리"""
        allowed = True
        if "bad-name" in request_data["request"]["object"]["metadata"]["name"]:
            allowed = False

        return {
            "apiVersion": "admission.k8s.io/v1",
            "kind": "AdmissionReview",
            "response": {
                "uid": uid,
                "allowed": allowed,
                "status": {"message": "Denied because of bad name"} if not allowed else {}
            }
        }

    def mutate_request(self, uid, request_data):
        """Mutate 요청 처리"""
        object_metadata = request_data["request"]["object"]["metadata"]
        patches = []

        if "bad-name" in object_metadata["name"]:
            new_name = object_metadata["name"].replace("bad-name", "sad-name")
            patches.append({
                "op": "replace",
                "path": "/metadata/name",
                "value": new_name
            })

        patch_base64 = base64.b64encode(json.dumps(patches).encode('utf-8')).decode('utf-8')
        logging.info(f"Generated JSON Patch: {json.dumps(patches, indent=2)}")

        return {
            "apiVersion": "admission.k8s.io/v1",
            "kind": "AdmissionReview",
            "response": {
                "uid": uid,
                "allowed": True,
                "patch": patch_base64,
                "patchType": "JSONPatch"
            }
        }

def run_server():
    server_address = ('0.0.0.0', 443)
    httpd = http.server.HTTPServer(server_address, AdmissionWebhookHandler)

    # SSL 적용
    httpd.socket = ssl.wrap_socket(httpd.socket,
                                   keyfile="/etc/tls/tls.key",
                                   certfile="/etc/tls/tls.crt",
                                   ca_certs="/etc/tls/ca.crt",
                                   server_side=True)

    logging.info("Starting server on port 443 with TLS...")
    httpd.serve_forever()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_server()

