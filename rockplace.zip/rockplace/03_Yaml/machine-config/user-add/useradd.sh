#!/bin/bash

user_id="$1"
user_pw="$2"
useradd -G wheel $user_id
echo $user_pw | passwd $user_id --stdin
