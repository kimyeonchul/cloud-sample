# Step 1. Create Machine Config Pool
[root@bastion ~]# oc create -f .

# Step 2. Remove worker role labels
[root@bastion ~]# for node in $(oc get node -o name | cut -d '/' -f '2' | grep -v "master|worker"); do oc label node $node node-role.kubernetes.io/worker-; done

# Step 3. Add router labels
[root@bastion ~]# for node in $(oc get node -o name | cut -d '/' -f '2' | grep "router"); do oc label node $node --overwrite node-role.kubernetes.io/router=""; done

# Step 4. Add infra labels
[root@bastion ~]# for node in $(oc get node -o name | cut -d '/' -f '2' | grep "infra"); do oc label node $node --overwrite node-role.kubernetes.io/infra=""; done

# Step 5. Add logging labels
[root@bastion ~]# for node in $(oc get node -o name | cut -d '/' -f '2' | grep "logging"); do oc label node $node --overwrite node-role.kubernetes.io/logging=""; done

# Step 6. Check MCP
# Rendered is machine config file merged.
# And rendered files is auto generated.
[root@bastion ~]# oc get mcp
