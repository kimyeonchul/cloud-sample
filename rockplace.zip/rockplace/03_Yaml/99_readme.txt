# Preparing to upgrade to OpenShift Container Platform 4.16
# https://access.redhat.com/articles/7031404
[root@bastion ~]# oc -n openshift-config patch cm admin-acks --patch '{"data":{"ack-4.15-kube-1.29-api-removals-in-4.16":"true"}}' --type=merge
