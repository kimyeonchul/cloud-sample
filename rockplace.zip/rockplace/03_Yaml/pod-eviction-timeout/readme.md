# RefURL: https://access.redhat.com/solutions/4306811
# pod-eviction-timeout, node-monitor-grace-period, node-monitor-period
[root@bastion ~]# oc edit kubecontrollermanagers cluster -n openshift-config
apiVersion: operator.openshift.io/v1
kind: KubeControllerManager
metadata:
  name: cluster
spec:
  unsupportedConfigOverrides:
    extendedArguments:
      pod-eviction-timeout:
      - 5m
      node-monitor-grace-period:
      - 20s
      node-monitor-period:
      - 40s
