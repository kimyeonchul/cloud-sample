# Egress Content

## 1. 파일 개요 
.  
├── deploy  
│   ├── egress-FW.yaml  
│   ├── egress-IP.yaml  
│   └── egress-Router.yaml  
└── test  
    ├── Dockerfile  
    ├── test-db-connect.yml  
    └── test.yml  
  

## 2. 필요 이미지 목록
- registry.access.redhat.com/ubi8:latest   DB연결 테스트 파드의 Base Image

## 3. 내부 참고 문서
- https://172.16.4.10/x/55VuBw
