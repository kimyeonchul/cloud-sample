# Step 1.
[root@bastion ~]# oc patch mcp master --type=merge --patch='{"metadata": {"labels": {"max-pods": "3096"}}}'

# Step 2.
[root@bastion ~]# oc patch mcp worker --type=merge --patch='{"metadata": {"labels": {"max-pods": "3096"}}}'
