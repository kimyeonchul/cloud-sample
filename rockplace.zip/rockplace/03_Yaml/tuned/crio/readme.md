# Step 1.
[root@bastion ~]# oc create -f crio-pid-limit.yaml

# Step 2.
[root@bastion ~]# oc patch mcp master --type=merge --patch='{"metadata": {"labels": {"crio-pid-limit": "pid-max"}}}'
[root@bastion ~]# oc patch mcp worker --type=merge --patch='{"metadata": {"labels": {"crio-pid-limit": "pid-max"}}}'
