## Enable etcd encryption ##
# Step 1. Edit API Server
[root@bastion ~]# oc edit apiserver
...
.....
spec:
  encryption:
    type: aesgcm

# Step 2. Check Encryption
# OpenShift API Server
[root@bastion ~]# oc get openshiftapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
EncryptionCompleted
All resources encrypted: routes.route.openshift.io

# KubeAPI Server
[root@bastion ~]# oc get kubeapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
EncryptionInProgress
Resource secrets is not encrypted

# OpenShift OAuth
[root@bastion ~]# oc get authentication.operator.openshift.io -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
EncryptionCompleted
All resources encrypted: oauthaccesstokens.oauth.openshift.io, oauthauthorizetokens.oauth.openshift.io

## Disabling etcd encryption ##
# Step 1. Edit API Server
[root@bastion ~]# oc edit apiserver
...
....
spec:
  encryption:
    type: identity



# Step 2. Check Encryption
# OpenShift API Server
[root@bastion ~]# oc get openshiftapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
DecryptionCompleted
Encryption mode set to identity and everything is decrypted

# KubeAPI Server
[root@bastion ~]# oc get kubeapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
DecryptionCompleted
Encryption mode set to identity and everything is decrypted

# OpenShift OAuth
[root@bastion ~]# oc get authentication.operator.openshift.io -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'

- Result Pass
DecryptionCompleted
Encryption mode set to identity and everything is decrypted
