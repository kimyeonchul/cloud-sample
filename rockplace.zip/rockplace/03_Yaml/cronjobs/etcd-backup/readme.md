# Step 1. Create Service Account
[root@bastion ~]# oc create -f 00_service-account.yaml

# Step 2. Create Cluter Role/Binding
[root@bastion ~]# oc create -f 01_cluster-role.yaml
[root@bastion ~]# oc create -f 02_cluster-role-binding.yaml

# Step 3. Modify & Create Cronjobs
[root@bastion ~]# vi 03_cronjobs-etcd-backup.yaml
- spec.template.spec.containers.args 
- spec.template.spec.containers.image

[root@bastion ~]# oc create -f 03_cronjobs-etcd-backup.yaml

# Step 99. Test job
[root@bastion ~]# oc create job etcd-backup --from=cronjob/etcd-backup -n openshift-etcd 
