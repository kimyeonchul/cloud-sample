# Step 1. Create Configmap
# Port: 443
[root@bastion ~]# oc create configmap mirror-registry-100y-cert --from-file=registry.ocp.local=ca.crt -n openshift-config

# Port: 5000
[root@bastion ~]# oc create configmap mirror-registry-100y-cert --from-file=registry.ocp.local..5000=ca.crt -n openshift-config

# Step 2. Add additionalTrustedCA
[root@bastion ~]# oc patch images.config.openshift.io/cluster --type=merge \
--patch '{"spec": {"additionalTrustedCA":{"name": "mirror-registry-100y-cert"}}}'

# Step 3. Create generic secret
[root@bastion ~]# oc create secret generic mirror-registry-100y-cert --from-file=registry.ocp.local..5000=ca.crt -n openshift-image-registry

# Step 4. Create Images Registry PV / PVC
# - NFS
[root@bastion ~]# oc create -f nfs/image-registry-pv.yaml
[root@bastion ~]# oc create -f nfs/image-registry-storage-pvc.yaml

# Local Storage: Create LVM
# infra03
[root@bastion ~]# ssh core@infra03
[core@infra03 ~]$ sudo -i
[root@infra03 ~]# pvcreate /dev/sdb
[root@infra03 ~]# vgcreate local-storage /dev/sdb
[root@infra03 ~]# lvcreate -l 100%FREE -n image-registry-data local-storage

# - Local Storage: Create Volume
[root@bastion ~]# oc create -f local-storage/image-registry-local-storage-volume.yaml

# - Local Storage: Change PV Access Modes (RWO->RWX)
[root@bastion ~]# oc patch pv/$(oc get pv --no-headers -l kubernetes.io/hostname=infra01.ocp.local | awk '{print $1}') \
--type=merge -p '{"spec": {"accessModes": ["ReadWriteMany"]}}'

# - Local Storage: Create PVC
[root@bastion ~]# oc create -f local-storage/image-registry-storage-pvc.yaml

# Step 5. Enable Image-Registry Pod
# - Node Role
[root@bastion ~]# oc patch configs.imageregistry/cluster --type=merge \
--patch '{"spec": {"managementState": "Managed", "nodeSelector": {"node-role.kubernetes.io/infra": ""},"replicas": 2, "storage": {"pvc": {"claim": ""}}}}'

# - Selected Node
[root@bastion ~]# oc patch configs.imageregistry/cluster --type=merge \
--patch '{"spec": {"managementState": "Managed", "nodeSelector": {"kubernetes.io/hostname": "infra01.ocp.local"},"replicas": 1, "storage": {"pvc": {"claim": ""}}}}'

# Step 99. Recovery Only
# - Node Role
[root@bastion ~]# oc patch configs.imageregistry/cluster --type=merge \
--patch '{"spec": {"managementState": "Removed", "nodeSelector": {"node-role.kubernetes.io/infra": ""},"replicas": 1, "storage": {}}}'

# - Selected Node
[root@bastion ~]# oc patch configs.imageregistry/cluster --type=merge \
--patch '{"spec": {"managementState": "Removed", "nodeSelector": {"kubernetes.io/hostname": "infra01.ocp.local"},"replicas": 1, "storage": {}}}'

## Add Insecure Registry ##
[root@bastion ~]# oc patch images.config.openshift.io/cluster --type=merge \
--patch '{"spec": {"registrySources":{"insecureRegistries":["registry.ocp.local:5000"]}}}'
