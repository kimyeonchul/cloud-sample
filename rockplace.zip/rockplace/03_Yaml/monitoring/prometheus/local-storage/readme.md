# Step 1. LVM
# infra01
[root@bastion ~]# ssh core@infra01
[core@infra01 ~]$ sudo -i
[root@infra01 ~]# pvcreate /dev/vdb
[root@infra01 ~]# vgcreate local-storage /dev/vdb
[root@infra01 ~]# lvcreate -L 4G -n alert-data01 local-storage
[root@infra01 ~]# lvcreate -l 100%FREE -n prometheus-data01 local-storage

# infra02
[root@bastion ~]# ssh core@infra02
[core@infra02 ~]$ sudo -i
[root@infra02 ~]# pvcreate /dev/vdb
[root@infra02 ~]# vgcreate local-storage /dev/vdb
[root@infra02 ~]# lvcreate -L 4G -n alert-data02 local-storage
[root@infra02 ~]# lvcreate -l 100%FREE -n prometheus-data02 local-storage

# infra03
[root@bastion ~]# ssh core@infra03
[core@infra03 ~]$ sudo -i
[root@infra03 ~]# pvcreate /dev/vdb
[root@infra03 ~]# vgcreate local-storage /dev/vdb
[root@infra03 ~]# lvcreate -l 100%FREE -n image-registry-data local-storage

# Step 2. Create Alert Manager Local Storage Volume
[root@bastion ~]# oc create -f 00_prometheus-alert-data-volume.yaml

# Step 3. Create Prometheus Local Stoage Volume
[root@bastion ~]# oc create -f 01_prometheus-data-volume.yaml

# Step 4. Apply Cluster Monitoring Config
[root@bastion ~]# oc create -f 02_cluster-monitoring-config.yaml
