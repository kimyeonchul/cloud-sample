# Description
guide on how to create an Infra node during the IPI cluster installation.

# Step.1
Convert the install-config.yaml of the IPI cluster into manifests.
[root@bastion01 ~]# cd /data/rockplace/00_Install_Config/ipi
[root@bastion01 ~]# openshift-install create manifests

# Step.2
[root@bastion01 ~]# cd manifests
[root@bastion01 ~]# cp /data/rockplace/03_Yaml/machine-set/infra/* .
[root@bastion01 ~]# for i in `ls -al | awk '{if($9 ~ "infra") {print $9}}'`; do sed -i 's,8hr6l,{cluster-mid-name},g' $i;done

# Step.3
[root@bastion01 ~]# cd /data/rockplace/00_Install_Config/ipi
[root@bastion01 ~]# openshift-install create cluster
