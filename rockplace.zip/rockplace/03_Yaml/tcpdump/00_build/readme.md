# NOTIFICATION
rhel-9-for-x86_64-baseos-rpms & rhel-9-for-x86_64-appstream-rpms rpms in rhel9-dvd iso file

# Step.1
mount /dev/sr0 /mnt
cp -r /mnt/{AppStream,BaseOS} /data/repos/

# Step.2
sh build.sh

# Step.99 - 405 Not Allowed Error
podman push registry.ocp.local:5000/custom/tcpdump:latest
