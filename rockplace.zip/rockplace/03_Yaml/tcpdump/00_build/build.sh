#!/bin/bash
podman build --rm -t registry.ocp.local:5000/custom/tcpdump:latest .
podman push --tls-verify=false registry.ocp.local:5000/custom/tcpdump:latest
