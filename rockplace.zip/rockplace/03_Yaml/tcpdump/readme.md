# Step 1. Create Namespace
[root@bastion ~]# oc new-project tcpdump

# Step 2. SCC
[root@bastion ~]# oc adm policy add-scc-to-user privileged -z default -n tcpdump

# Step 3. Deploy Daemonset
[root@bastion ~]# oc create -f 01_yaml/tcpdump-daemonset.yaml -n tcpdump
