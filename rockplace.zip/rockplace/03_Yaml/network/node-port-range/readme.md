# Step 1. Change node port range
[root@bastion ~]# oc patch network.config.openshift.io cluster --type=merge --patch='{"spec":{ "serviceNodePortRange": "30000-39999" }}'
