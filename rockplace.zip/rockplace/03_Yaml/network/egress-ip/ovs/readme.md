# Set EgressIP
[root@bastion ~]# oc patch netnamespace egress-test --type=merge -p '{"egressIPs": ["ip-address"]}'
or
[root@bastion ~]# oc patch netnamespace egress-test --type=merge -p '{"egressCIDRs": ["ip-address/bits"]}'

# Confirm
[root@bastion ~]# oc get netnamespace
[root@bastion ~]# oc get hostsubnets.network.openshift.io
