#!/bin/bash
oc create secret generic idp-htpasswd-secret \
--from-file=htpasswd=file.db -n openshift-config
