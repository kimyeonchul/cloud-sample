#### Configuring an HTPasswd identity provider ####
# Step 1. Create New User
[root@bastion ~]# htpasswd -cb file.db [user-id] [user-password]

# Step 2. Create Secret for HTPasswd
[root@bastion ~]# oc create secret generic idp-htpasswd-secret --from-file=htpasswd=file.db -n openshift-config

# Step 3. Adding an identity provider to your clusters
[root@bastion ~]# oc replace -f idp-htpasswd-oauth.yaml

# Step 99. Add existing user accounts update and new accounts
[root@bastion ~]# htpasswd -b file.db [new-user-id] [new-user-password]

# Step 99. Confirm existing user account's password
[root@bastion ~]# htpasswd -v file.db [existing-user-id] [existing-user-password]

#### Update HTPasswd Users ####
# Step 1. Backup HTPasswd
[root@bastion ~]# oc get secret idp-htpasswd-secret -ojsonpath={.data.htpasswd} -n openshift-config | base64 --decode > file.db

# Step 2. Add existing user accounts update and new accounts
[root@bastion ~]# htpasswd -b file.db [new-user-id] [new-user-password]

# Step 3. Replace Secret file for idp-htpasswd-secret
[root@bastion ~]# oc create secret generic idp-htpasswd-secret --from-file=htpasswd=file.db --dry-run=client -o yaml -n openshift-config | oc replace -f -


#### Grant Cluster Administrator Role ####
# Step 1. Grant cluster-admin Role to User
[root@bastion ~]# oc adm policy add-cluster-role-to-user cluster-admin admin

# Step 2. Verify User Permissions
[root@bastion ~]# oc auth can-i '' '' --as=admin



