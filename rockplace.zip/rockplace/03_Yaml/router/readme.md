# Step 1. Create Secret
[root@bastion ~]# oc create secret tls router-100y-cert --cert=tls.crt --key=tls.key -n openshift-ingress

# Step 2. Create ConfigMap
[root@bastion ~]# oc create configmap router-100y-cert --from-file=ca-bundle.crt=tls.crt -n openshift-config

# Step 3. Add trustedCA
[root@bastion ~]# oc patch proxy/cluster --type=merge --patch='{"spec":{"trustedCA":{"name":"user-ca-bundle"}}}'

# Step 3. Replace ingress-controller pod
[root@bastion ~]# oc patch ingresscontrollers/default -n openshift-ingress-operator --type=merge \
-p '{"spec": {"defaultCertificate": {"name": "router-100y-cert"}, "replicas": 3, "nodePlacement": {"nodeSelector": {"matchLabels": {"node-role.kubernetes.io/worker": ""}}}}}'

# Ingress Controller(Router Pod): Max Connection Check
[root@bastion ~]# oc rsh -n openshift-ingress <ROUTER-POD> bash -c 'echo "show info" | socat /var/lib/haproxy/run/haproxy.sock stdio' | grep Maxconn 



